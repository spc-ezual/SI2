package fr.istic.si2.checkpoint1

object ExercicesCP1 extends App {

  /**
   * @param x un entier
   * @return la valeur absolue de x
   *         (la valeur de x sans tenir compte de son signe)
   */
  def valeurAbsolue(x: Int): Int = if (x < 0) -x else x

  /**
   * @param s une chaîne de caractères quelconque
   * @return vrai si et seulement si s correspond exactement à "a", "b", ou "c"
   * @note attention, les chaînes sont en minuscules.
   */
  def abc(s: String): Boolean = {
    s match {
      case "a" => true

      case "b" => true

      case "c" => true

      case _   => false
    }
  }

  /**
   * @param m un entier
   * @param x un entier
   * @param y un entier
   * @return vrai si et seulement si m est le minimum de x et y
   * @note Exemples :
   *       - 4 est le minimum de 6 et 4
   *       - 6 n'est pas le minimum de 4 et 6
   *       - 6 est le minimum de 6 et 6
   *       - 8 n'est pas le minimum de 12 et 1
   */
  def estMin(m: Int, x: Int, y: Int): Boolean = {
    (m == x && x <= y) || (m == y && y <= x)
  }
}
