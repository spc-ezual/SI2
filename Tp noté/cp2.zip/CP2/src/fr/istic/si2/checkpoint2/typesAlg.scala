package fr.istic.si2.checkpoint2

import math._

/**
 * On souhaite modéliser des rendus de checkpoints d'étudiants.
 *
 * Chaque rendu appartient à un étudiant, modélisé par son numéro d'étudiant (une chaîne)
 * On modélise des rendus suivants :
 * - les étudiants absents
 * - les rendus invalides, pour cause de retard, d'erreur de compilation, ou de mauvais export
 * - les rendus évaluables. Dans ce cas, on garde trace :
 *        - du nombre de points sur lequel est noté le CP
 *        - du mombre de warnings
 *        - du nombre de tests échoués
 *
 * La modélisation utilise les types algébriques Motif et RenduCP, fournis plus bas.
 */
sealed trait Motif
case object Retard extends Motif
case object Error extends Motif
case object MauvaisFormat extends Motif

sealed trait RenduCP
case class Absent(etu: String) extends RenduCP
case class Invalide(etu: String, motif: Motif) extends RenduCP
case class OK(etu: String, totalPointCP: Int, nbWarn: Int, nbTestFail: Int) extends RenduCP

object QuestionTypesAlgebriques extends App {

  /**
   * Rendu invalide pour cause d'une erreur dans le projet.
   * Vous êtes libre dans le choix du numéro d'étudiant.
   */
  val r1: RenduCP = Invalide("12345", Error)

  /**
   * Rendu pour un étudiant absent le jour de l'épreuve.
   * Vous êtes libre dans le choix du numéro d'étudiant.
   */
  val r2: RenduCP = Absent("56789")

  /**
   * Rendu pour un étudiant qui a soumis au bon format, et à l'heure.
   * Il obtient 4 tests échoués, 1 warning, pour un CP noté sur 8 points.
   */
  val r3: RenduCP = OK("12456789", 8, 1, 4)

  /**
   * @param cp un rendu de checkpoint
   * @param etu un numero d'étudiant
   * @return vrai si et seulement si cp est le rendu de l'étudiant etu
   */
  def sonRendu(cp: RenduCP, etu: String): Boolean = {
    cp match {
      case Invalide(n, _) => n == etu
      case Absent(n)      => n == etu
      case OK(n, _, _, _) => n == etu
    }
  }

  /**
   * @param cp un rendu de checkpoint
   * @return l'étudiant ayant rendu cp, suivi de sa note, s'il était présent.
   *         un rendu invalide n'a aucun point.
   *         chaque test échoué coûte 2 points, et chaque warning coûte 1 point.
   *         ces pénalités sont retranchées au total des points.
   *         la note plancher est 0.
   */
  def note(cp: RenduCP): (String, Option[Int]) = {
    cp match {
      case Absent(n)                     => (n, None)
      case Invalide(n, _)                => (n, Some(0))
      case OK(n, nm, nbWarn, nbTestFail) => (n, Some(max(0, nm - (2 * nbTestFail + nbWarn))))
    }
  }

}
