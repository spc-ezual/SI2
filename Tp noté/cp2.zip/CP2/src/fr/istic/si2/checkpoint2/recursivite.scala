package fr.istic.si2.checkpoint2

import scala.math._

object QuestionRecursivite extends App {

  /**
   * @param n un entier strictement positif
   * @param p un entier compris entre 1 et 9
   * @return l'entier dont l'écriture est composée de n chiffres, tous égaux à p
   *         Exemples :
   *         suiteDe(4,3) vaut l'entier 3333
   *         suiteDe(6,1) vaut l'entier 111111
   */
  def suiteDe(n: Int, p: Int): Int = {
    n match {
      case 0 => 0
      case _ => p + 10 * suiteDe(n - 1, p)
    }
  }

}
