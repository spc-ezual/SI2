package fr.istic.si2.test.checkpoint2

import fr.istic.si2.checkpoint2.QuestionTypesAlgebriques
import fr.istic.si2.checkpoint2.QuestionTypesAlgebriques._
import fr.istic.si2.checkpoint2._
import util.Random
import org.scalacheck._
import Gen.{ fail => _, _ }
import Arbitrary.arbitrary

object UtilsGen {

  val rand = new Random()

  

  val genMotif: Gen[Motif] = Gen.oneOf(Error, MauvaisFormat, Retard)
  val genAbsent = {
    for {
      id <- arbitrary[String]
    } yield Absent(id)
  }
  val genInvalide = {
    for {
      id <- arbitrary[String]
      m <- genMotif
    } yield Invalide(id, m)
  }
  val genOKpos = {
    for {
      id <- arbitrary[String]
      fl <- arbitrary[Int] suchThat (_ >= 0) suchThat (_ <= 20)
      wrn <- arbitrary[Int] suchThat (_ >= 0) suchThat (_ <= 20)
    } yield OK(id, 3 * fl + 2 * wrn, wrn, fl)
  }
  val genOKneg = {
    for {
      id <- arbitrary[String]
      fl <- arbitrary[Int] suchThat (_ >= 0) suchThat (_ <= 20)
      wrn <- arbitrary[Int] suchThat (_ >= 0) suchThat (_ <= 20)
    } yield OK(id, fl + wrn, wrn, fl)
  }
  val genRendu = oneOf(genAbsent, genInvalide, genOKpos, genOKneg)

  val id: RenduCP => String = { r =>
    r match {
      case Absent(id)      => id
      case Invalide(id, _) => id
      case OK(id, _, _, _) => id
    }
  }

  
}
