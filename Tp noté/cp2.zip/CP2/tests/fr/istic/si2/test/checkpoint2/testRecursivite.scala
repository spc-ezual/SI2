package fr.istic.si2.test.checkpoint2

import org.junit.Test
import org.junit.Assert._
import util.Random
import fr.istic.si2.testerApp._
import fr.istic.si2.moreAssertions._
import fr.istic.si2.checkpoint2.QuestionRecursivite
import fr.istic.si2.checkpoint2.QuestionRecursivite._
import fr.istic.si2.checkpoint2._
import ImpOracles._

import fr.istic.si2.checkpoint.oracles.Consignes._

class RecursiviteDefinitionTest {

  val rand = new Random()
  val exos = parseFile("recursivite.scala", "fr.istic.si2.checkpoint2")

  /**
   * suiteDe est bien définie
   */
  @Test(timeout = 30000)
  def suiteDeDefined {
    isDefined(suiteDe(42, 3))
  }

  /**
   * suiteDe est récursive, et n'utilise pas de boucle
   */
  @Test(timeout = 30000)
  def suiteDeStyle {
    val f = "suiteDe"
    val isRec = checkFunctionP(f, exos, isRecursive(_))
    if (!isRec) fail(messagerecdirecte(f))

    val noLoop = checkFunctionP(f, exos, hasNoLoop(_))
    if (!noLoop) fail(messageNoLoop(f))

  }

}

class RecursiviteCorrectionTest {

  val rand = new Random()
  val exos = parseFile("recursivite.scala", "fr.istic.si2.checkpoint2")

  /**
   * suiteDe est correcte - cas de base
   */
  @Test(timeout = 30000)
  def suiteDeOKbase {
    for (i <- 1 until 10) {
      assertEquals(suiteDeOracle(1, i), suiteDe(1, i))
    }
  }

  /**
   * suiteDe est correcte - cas récursifs
   */
  @Test(timeout = 30000)
  def suiteDeOKother {
    for (_ <- 1 to 1000) {
      val n = rand.nextInt(8) + 1
      val p = rand.nextInt(8) + 1
      assertEquals(suiteDeOracle(n, p), suiteDe(n, p))
    }
  }

}

object ImpOracles {

  /**
   * @param n un entier strictement positif
   * @param p un entier compris entre 0 et 9
   * @return l'entier dont l'écriture est composée de n chiffres, tous égaux à p
   */
  def suiteDeOracle(n: Int, p: Int): Int = {
    List.fill(n)(p).map(_.toString).reduce(_ + _).toInt
  }

}
