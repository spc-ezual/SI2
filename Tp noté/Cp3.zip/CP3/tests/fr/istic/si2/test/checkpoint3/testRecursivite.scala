package fr.istic.si2.test.checkpoint3

import org.junit.Test
import org.junit.Assert._
import util.Random
import fr.istic.si2.testerApp._
import fr.istic.si2.moreAssertions._
import fr.istic.si2.checkpoint3.QuestionRecursivite
import fr.istic.si2.checkpoint3.QuestionRecursivite._
import fr.istic.si2.checkpoint3._
import fr.istic.si2.checkpoint.oracles.Oracles._
import fr.istic.si2.checkpoint.oracles.Consignes._
import fr.istic.si2.checkpoint.oracles.Consignes
import fr.istic.si2.checkpoint.oracles.{ Bit, Zero, One }

class RecursiviteDefinitionTest {
  val rand = new Random()
  val exos = parseFile("recursivite.scala", "fr.istic.si2.checkpoint3")

  /**
   * dernierBitNul est bien définie
   */
  @Test(timeout = 30000)
  def dernierBitNulDefined {
    isDefined(dernierBitNul(Nil))
  }

  /**
   * dernierBitNul est récursive directe, et n'utilise pas de boucle
   */
  @Test(timeout = 30000)
  def dernierBitNulStyle {
    checkStyleRec(exos, "dernierBitNul")
  }

  /**
   * opposes est bien définie
   */
  @Test(timeout = 30000)
  def opposesDefined {
    isDefined(opposes(Nil))
  }

  /**
   * opposes est récursive directe, et n'utilise pas de boucle
   */
  @Test(timeout = 30000)
  def opposesStyle {
    checkStyleRec(exos, "opposes")
  }

  /**
   * compte est bien définie
   */
  @Test(timeout = 30000)
  def compteDefined {
    isDefined(compte(Nil, 0))
  }

  /**
   * compte est récursive directe, et n'utilise pas de boucle
   */
  @Test(timeout = 30000)
  def compteStyle {
    checkStyleRec(exos, "compte")
  }

  /**
   * sommeEgalA est bien définie
   */
  @Test(timeout = 30000)
  def sommeEgalADefined {
    isDefined(sommeEgalA(Nil, 4))
  }

  /**
   * sommeEgalA est récursive directe, et n'utilise pas de boucle
   */
  @Test(timeout = 30000)
  def sommeEgalAStyle {
    checkStyleRec(exos, "sommeEgalA")
  }

}

class RecursiviteCorrectionTest {

  val rand = new Random()
  val exos = parseFile("recursivite.scala", "fr.istic.si2.checkpoint3")

  /**
   * @return un Bit au hasard
   */
  def genBit(): Bit = {
    if (rand.nextBoolean()) Zero else One
  }

  /**
   * dernierBitNul est correcte - cas de base
   */
  @Test(timeout = 30000)
  def dernierBitNulOKbase {
    assertEquals(oraclecodeEntierPair(List[Bit]()), dernierBitNul(Nil))
  }

  /**
   * dernierBitNul est correcte - cas récursifs
   */
  @Test(timeout = 30000)
  def dernierBitNulOKother {
    for (_ <- 1 to 100) {
      val s = genBit()
      val l = Seq.fill(Random.nextInt(40))(genBit()).toList ++ (s :: Nil)
      assertEquals(oraclecodeEntierPair(l), dernierBitNul(l))
    }
  }

  /**
   * opposes est correcte - cas de base
   */
  @Test(timeout = 30000)
  def opposesOKbase {
    assertEquals(oracleopposes(List[Int]()), opposes(Nil))
  }

  /**
   * opposes est correcte - cas récursifs
   */
  @Test(timeout = 30000)
  def opposesOKother {
    for (_ <- 1 to 100) {
      val s = Random.nextInt(2000)
      val l = s :: Seq.fill(Random.nextInt(50))(Random.nextInt(2000)).toList
      assertEquals(oracleopposes(l), opposes(l))
    }
  }

  /**
   * compte est correcte - cas de base
   */
  @Test(timeout = 30000)
  def compteOKbase {
    for (_ <- 1 to 1000) {
      val n = Random.nextInt(100)
      assertEquals(oraclecompte(n)(List[Int]()), compte(Nil, n))
    }
  }

  /**
   * compte est correcte - cas récursifs
   */
  @Test(timeout = 30000)
  def compteOKother {
    for (_ <- 1 to 100) {
      val n = Random.nextInt(10)
      val s = Random.nextInt(50)
      val l = s :: Seq.fill(Random.nextInt(100))(Random.nextInt(10)).toList
      assertEquals(oraclecompte(n)(l), compte(l, n))
    }
  }

  /**
   * sommeEgalA est correcte - cas de base
   */
  @Test(timeout = 30000)
  def sommeEgalAOKbase {
    for (_ <- 1 to 1000) {
      assertTrue(sommeEgalA(Nil, 0))
      assertFalse(sommeEgalA(Nil, 1 + math.abs(Random.nextInt(50))))
    }
  }

  /**
   * sommeEgalA est correcte - cas récursifs
   */
  @Test(timeout = 30000)
  def sommeEgalAOKother {
    for (_ <- 1 to 100) {
      val s = Random.nextInt(50)
      val l = s :: Seq.fill(Random.nextInt(100))(Random.nextInt(10)).toList
      assertTrue(sommeEgalA(l, oraclesomme(l)))

    }

    var i = 0
    while (i < 100) {
      val s = Random.nextInt(50)
      val l = s :: Seq.fill(Random.nextInt(100))(Random.nextInt(10)).toList
      val n = Random.nextInt(l.length * 2)
      if (n != oraclesomme(l)) {
        assertFalse(sommeEgalA(l, n))
        i += 1
      }
    }
  }

}

