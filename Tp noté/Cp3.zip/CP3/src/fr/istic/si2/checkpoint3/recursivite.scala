package fr.istic.si2.checkpoint3

import fr.istic.si2.checkpoint.oracles.{ Bit, Zero, One }

object QuestionRecursivite extends App {

  /**
   * @param l une liste d'entiers
   * @return la liste des entiers opposés aux éléments de l, dans l'ordre
   */
  def opposes(l: List[Int]): List[Int] = {
    l match{
      case Nil => Nil
      case a::as => -1*a::opposes(as)
    }
  }

  /**
   * @param l une de liste d'entiers
   * @param n un entier
   * @return le nombre de fois où n apparaît dans l
   */
  def compte(l: List[Int], n: Int): Int = {
    l match {
      case Nil => 0
      case a::as => compte(as,n) + (if(a==n) 1 else 0)
    }
  }

  /**
   * @param l une liste d'entiers
   * @param e un entier
   * @return vrai si et seulement si la somme des éléments de l vaut e
   * @note   Convention: la somme de zéro élément vaut zéro
   */
  def sommeEgalA(l: List[Int], e: Int): Boolean = {
    l match{
      case Nil => e==0
      case a::as => sommeEgalA(as,e-a)
    }
  }

  /**
   * @param lb une liste de bits 
   * @return vrai ssi le dernier bit de lb est nul
   * @note Convention: une liste vide de bits n'a pas son dernier bit nul
   */
  def dernierBitNul(lb: List[Bit]): Boolean = {
    lb match {
      case Nil => false
      case a::Nil => a==Zero
      case a::as => dernierBitNul(as)
    }
  }
}

