package fr.istic.si2.tp2.images

import fr.istic.si2.scribble._

import scala.io.StdIn._

object Motifs extends App {

  // Définition des images illustrant la météo
  val sun: Image = FromFile("./img/sun.png") 
  val cloud: Image = FromFile("./img/cloud.png") 
  
  /**
   * Une image de soleil cachée par un nuage.
   */
  val cloudy: Image = onBackAt(cloud,sun,-30,-20)
  /**
   * @param i une image
   * @param c une couleur
   * @return image i coloriée et tracée avec la couleur c (si i n'est pas déjà coloriée)
   */
  def allColor(i: Image, c: Color): Image = {
    fillColor(lineColor(i, c), c)
  }

  
  // Définitions d'images illustrant les contrôles média courants
  /**
   * Une image illustrant l'arrêt de la lecture et la remise à zéro (STOP)
   */
  val stop: Image = allColor(Rectangle(30,30),RED)
  draw(stop)
  /**
   * Une image illustrant l'arrêt de la lecture (PAUSE)
   */
  val pause: Image = allColor(onBackAt(Rectangle(10,30),Rectangle(10,30),16,0),GREEN)

  /**
   * Une image illustrant le démarrage de la lecture (PLAY) 
   */
  val play: Image = allColor(rotate(Triangle(30),-90),BLUE)
  
  /**
   * Une image illustrant la sélection de la prochaine piste (NEXT)
   */
  val next: Image = allColor(Beside(Beside(rotate(Triangle(30),-90),rotate(Triangle(30),-90)),Rectangle(6,30)),BLACK)
  
  /**
   * Une image illustrant la sélection de la piste précédente (PREVIOUS)
   */
  val previous: Image = allColor(Beside(Beside(Rectangle(6,30),rotate(Triangle(30),90)),rotate(Triangle(30),90)),BLACK)
  draw(stop)
  draw(pause)
  draw(play)
  draw(next)
  draw(previous)

}
