package fr.istic.si2.test.tp6.tri

import org.junit.Test

import org.junit.Assert._
import util.Random
import fr.istic.si2.testerApp._
import fr.istic.si2.moreAssertions._
import fr.istic.si2.math._

import fr.istic.si2.tp6.tri.TriEntiers._
import fr.istic.si2.tp6.tri.TriEntiers

import java.io.PrintStream

class TriEntiersCorrectionTest {

  val _ = new AppInit(TriEntiers)

  // Vous devrez compléter ces fichiers de test.
  // Idéalement, plusieurs tests, bien choisis, doivent être effectués sur chaque fonction.
  // Attention, testez également la fonction versionTriee sur des listes non triées ! Pour cela, utiliser l'assertion assertFalse.

  /**
   * la fonction versionTriee est correcte
   */
  @Test(timeout = 100)
  def versionTrieeCorrect {
   ???
  }

  /**
   * la fonction triInsertion trie correctement
   */
  @Test(timeout = 1000)
  def triInsertionCorrect {
    ???
  }

}