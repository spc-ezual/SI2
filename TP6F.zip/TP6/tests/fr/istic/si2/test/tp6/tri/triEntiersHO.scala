package fr.istic.si2.test.tp6.tri

import org.junit.Test

import org.junit.Assert._
import util.Random
import fr.istic.si2.testerApp._
import fr.istic.si2.moreAssertions._
import fr.istic.si2.math._

import fr.istic.si2.tp6.tri.TriEntiersHO._
import fr.istic.si2.tp6.tri.TriEntiersHO

import java.io.PrintStream

class TriEntiersHOCorrectionTest {

  val _ = new AppInit(TriEntiersHO)

  /**
   *  la fonction triCroissant est correcte
   */
  @Test(timeout = 100)
  def triCroissantCorrection {
    ???
  }

  /**
   *  la fonction triDecroissant est correcte
   */
  @Test(timeout = 100)
  def triDecroissantCorrection {
    ???
  }

  /**
   *  la fonction triPairDabord est correcte
   */
  @Test(timeout = 100)
  def triPairDabordCorrection {
    ???
  }

  /**
   *  la fonction triNegatifDabord est correcte
   */
  @Test(timeout = 100)
  def triNegatifDabordCorrection {
    ???
  }

}