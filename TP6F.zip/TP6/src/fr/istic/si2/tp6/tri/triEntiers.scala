package fr.istic.si2.tp6.tri

import fr.istic.si2.tp5.permutations.Permuts._
import scala.annotation.tailrec

object TriEntiers extends App {

  /**
   * @param e un entier à insérer dans une liste triée dans l'ordre croissant
   * @param l une liste triée
   * @return la liste triée dans l'ordre croissant résultant de l'insertion de e dans l au bon endroit
   */
  def insertion(e: Int, l: List[Int]): List[Int] = {
    l match {
      case ::(head, next) => if (head < e) head :: insertion(e, next) else e :: l
      case Nil            => List(e)
    }
  }

  /**
   * @param l une liste d'entiers quelconque
   * @return la liste contenant les mêmes éléments que l, triée dans l'ordre croissant
   */
  def triInsertion(l: List[Int]): List[Int] = {
    l match {
      case ::(head, next) => insertion(head, triInsertion(next))
      case Nil            => Nil
    }
  }

  /**
   * @param l1 une liste d'entiers
   * @param l2 une liste d'entiers
   * @return vrai si et seulement si l2 est la version triée dans l'ordre croissant de l1
   *
   * @note Indication utiliser la fonction permutation indiquee dans l'énoncé
   */
  def versionTriee(l1: List[Int], l2: List[Int]): Boolean = {
    l1.sorted == l2
  }
}
