package fr.istic.si2.tp6.tri

import fr.istic.si2.tp5.permutations.Permuts._
import scala.annotation.tailrec

object TriPolyHO extends App {

  /**
   * @tparam A le type des éléments de la liste
   * @param cmp une fonction de comparaison sur A
   * @param e un element à insérer
   * @param l une liste triée selon cmp
   * @return la liste triée selon cmp, résultant de l'insertion de e dans l au bon endroit
   */
  def insertion[A](cmp: (A, A) => Boolean, e: A, l: List[A]): List[A] = {
    l match {
      case ::(head, next) => if (cmp(head, e)) head :: insertion[A](cmp, e, next) else e :: l
      case Nil            => List(e)
    }
  }

  /**
   * @tparam A le type des éléments de la liste
   * @param cmp une fonction de comparaison sur A
   * @param l une liste
   * @return la liste des éléments de l, triée selon cmp.
   */
  def triInsertion[A](cmp: (A, A) => Boolean, l: List[A]): List[A] = {
    l match {
      case ::(head, next) => insertion[A](cmp, head, triInsertion[A](cmp, next))
      case Nil            => Nil
    }
  }

  /**
   * @tparam A le type des éléments de la liste
   * @param cmp une fonction de comparaison sur les A
   * @param l1 une liste
   * @param l2 une liste
   * @return vrai si et seulement si l2 est la version triée dans l'ordre cmp.
   *
   * @note Indication utiliser la fonction permutation indiquee dans l'énoncé
   */

  def versionTriee[A](cmp: (A, A) => Boolean, l1: List[A], l2: List[A]): Boolean = {
    l1.sortWith(cmp) == l2
  }

  /**
   * @param l une liste d'entiers
   * @return la liste des éléments de l, triée en ordre croissant
   */
  // Votre fonction devra utiliser la fonction polymorphe triInsertion
  def triCroissant(l: List[Int]): List[Int] = {
    triInsertion[Int]((X, Z) => X < Z, l)
  }

  /**
   * @param l une liste d'entiers
   * @return la liste des éléments de l, triée en ordre décroissant
   */
  // Votre fonction devra utiliser la fonction polymorphe triInsertion
  def triDecroissant(l: List[Int]): List[Int] = {
    triInsertion[Int]((X, Z) => X > Z, l)
  }

  /**
   * @param l une liste d'entiers
   * @return la liste des éléments de l, triée en plaçant
   *         les éléments pairs avant les éléments impairs
   */
  // Votre fonction devra utiliser la fonction polymorphe triInsertion
  def triPairDabord(l: List[Int]): List[Int] = {
    triInsertion[Int](_ % 2 == 0 && _ % 2 == 1, l)
  }

  /**
   * @param l une liste d'entiers
   * @return la liste des éléments de l, triée en plaçant
   *         les éléments négatifs avant les éléments positifs
   */
  // Votre fonction devra utiliser la fonction polymorphe triInsertion
  def triNegatifDabord(l: List[Int]): List[Int] = {
    triInsertion[Int]((X, Y) => X < 0 && Y >= 0, l)
  }

  /**
   * @param l une liste de chaînes
   * @return la liste des éléments de l, triée en utilisant
   *         l'ordre alphabétique sur les chaînes (compareTo)
   */
  // Votre fonction devra utiliser la fonction polymorphe triInsertion
  def triAvantAlpha(l: List[String]): List[String] = {
    triInsertion[String](_.compareTo(_) < 0, l)
  }

  /**
   * @param l une liste de chaînes
   * @return la liste des éléments de l, triée selon la taille des chaînes
   *         (les plus courtes sont avant les plus longues)
   */
  // Votre fonction devra utiliser la fonction polymorphe triInsertion
  def triPlusCourte(l: List[String]): List[String] = {
    triInsertion[String](_.length < _.length, l)
  }

  /**
   * @param l une liste de paires d'entiers
   * @return la liste des éléments de l, triée selon l'ordre lexicographique
   *         une paire (x,y) est inférieure à (z,t) si
   *         - soit x est inférieur à z,
   *         - soit x = z et y est inférieur à t
   */
  // Votre fonction devra utiliser la fonction polymorphe triInsertion
  def triOrdrePaires(l: List[(Int, Int)]): List[(Int, Int)] = {
    triInsertion[(Int, Int)]((X, Z) => X._1 < Z._1 || (X._1 == Z._1 && X._2 < Z._2), l)

  }
  /**
   *  @param l list d'etudiant
   *  @return la liste trier en fontion du numero etudiant
   */
  def trieNumEtu(l: List[NoteEtu]): List[NoteEtu] = {
    triInsertion[NoteEtu]((X, Z) => X.NumEtu < Z.NumEtu, l)
  }

  /**
   *  @param l list d'etudiant
   *  @return la liste trier en fontion des nom et prenom
   */
  def trieNomPre(l: List[NoteEtu]): List[NoteEtu] = {
    triInsertion[NoteEtu]((X, Z) => X.Nom.compareTo(Z.Nom) < 0 || (X.Nom.compareTo(Z.Nom) == 0 && X.Prenom.compareTo(Z.Prenom) < 0), l)
  }

  /**
   *  @param l list d'etudiant
   *  @return la liste trier en fontion des note
   */
  def trieNoteEtu(l: List[NoteEtu]): List[NoteEtu] = {
    triInsertion[NoteEtu]((X, Z) => X.Note < Z.Note, l)
  }

  val a = List(NoteEtu("azery", "az", 159753, 12), NoteEtu("tgfb", "zaeaz", 7845, 15), NoteEtu("azery", "nov", 78945, 2), NoteEtu("tbzac", "eaz", 1268, 20))
  println(trieNomPre(a))
}

case class NoteEtu(Nom: String, Prenom: String, NumEtu: Int, Note: Int)
