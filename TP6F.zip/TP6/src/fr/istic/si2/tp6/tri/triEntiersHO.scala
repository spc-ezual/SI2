package fr.istic.si2.tp6.tri

import fr.istic.si2.tp5.permutations.Permuts._
import scala.annotation.tailrec

object TriEntiersHO extends App {

  /**
   * @param cmp une fonction de comparaison entre entiers
   * @param e un entier à insérer dans une liste triée selon cmp
   * @param l une liste triée selon cmp
   * @return la liste triée selon cmp résultant de l'insertion de e dans l au bon endroit
   */
  def insertion(cmp: (Int, Int) => Boolean, e: Int, l: List[Int]): List[Int] = {
    l match {
      case ::(head, next) => if (cmp(head, e)) head :: insertion(cmp, e, next) else e :: l
      case Nil            => List(e)
    }
  }

  /**
   * @param cmp une fonction de comparaison sur les entiers
   * @param l une liste d'entiers quelconque
   * @return la liste contenant les mêmes éléments que l, triée selon cmp.
   */
  def triInsertion(cmp: (Int, Int) => Boolean, l: List[Int]): List[Int] = {
    l match {
      case ::(head, next) => insertion(cmp, head, triInsertion(cmp, next))
      case Nil            => Nil
    }
  }

  /**
   * @param cmp une fonction de comparaison sur les entiers
   * @param l1 une liste d'entiers
   * @param l2 une liste d'entiers
   * @return vrai si et seulement si l2 est la version triée dans l'ordre cmp.
   *
   * @note Indication utiliser la fonction permutation indiquee dans l'énoncé
   */
  def versionTriee(cmp: (Int, Int) => Boolean, l1: List[Int], l2: List[Int]): Boolean = {
    l1.sortWith(cmp) == l2
  }

  /**
   * @param l une liste
   * @return la liste des éléments de l, triée en ordre croissant
   */
  // Votre fonction devra utiliser la fonction d'ordre sup. triInsertion
  def triCroissant(l: List[Int]): List[Int] = {
    triInsertion(Ordering.Int.lt, l)
  }

  /**
   * @param l une liste
   * @return la liste des éléments de l, triée en ordre décroissant
   */
  // Votre fonction devra utiliser la fonction d'ordre sup. triInsertion
  def triDecroissant(l: List[Int]): List[Int] = {
    triInsertion(Ordering.Int.gt, l)
  }

  /**
   * @param l une liste
   * @return la liste des éléments de l, triée en plaçant
   *         les éléments pairs avant les éléments impairs
   */
  // Votre fonction devra utiliser la fonction d'ordre sup. triInsertion
  def triPairDabord(l: List[Int]): List[Int] = {
    triInsertion(_ % 2 == 0 && _ % 2 == 1, l)
  }

  /**
   * @param l une liste
   * @return la liste des éléments de l,  triée en plaçant
   *         les éléments négatifs avant les élements positifs
   */
  // Votre fonction devra utiliser la fonction d'ordre sup. triInsertion
  def triNegatifDabord(l: List[Int]): List[Int] = {
    triInsertion((X, Y) => X < 0 && Y >= 0, l)
  }
}
