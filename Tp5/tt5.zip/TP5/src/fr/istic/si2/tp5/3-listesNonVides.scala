package fr.istic.si2.tp5

import org.junit.Assert._

/**
 * Type algébrique récursif permettant de modéliser
 * des listes d'entiers non vides
 */
sealed trait ListeNVE
case object Nul extends ListeNVE
case class Constr(head: Int, tail: ListeNVE) extends ListeNVE

object ExosListesNonVides extends App {

  /**
   * @param l une liste non vide d'entiers
   * @return le dernier élément de l
   */
  def dernier(l: List[Int]): Int = {
    l.tail.isEmpty match {
      case true => l.head
      case _    => dernier(l.tail)
    }
  }

  /**
   * @param l une ListeNVE quelconque
   * @return le dernier élément de l
   */
  def dernier(l: ListeNVE): Int = {
    l match {
      case Constr(z, Nul) => z
      case Constr(_, zs)  => dernier(zs)
      case Nul            => -1
    }
  }

}
