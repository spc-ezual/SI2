package fr.istic.si2.tp5

import org.junit.Assert._

case class UnknownId() extends Exception

object ExosListes extends App {

  /**
   * @param n un entier positif ou nul
   * @param p un entier quelconque
   * @return la liste de longueur n, contenant n fois l'entier p
   */
  def nfois(n: Int, p: Int): List[Int] = {
    n match {
      case 0 => List()
      case _ => p :: nfois(n - 1, p)
    }
  }

  /**
   * @param l une liste de chaînes quelconques
   * @return la chaîne formée de la concaténation des éléments de l, dans l'ordre
   */
  def concat(l: List[String]): String = {
    l.isEmpty match {
      case true  => ""
      case false => l.head + concat(l.tail)
    }
  }

  /**
   *
   * @param l une liste d'entiers
   * @param ord ordre Nombre
   *
   * @return la liste des éléments de l, triée dans l'ordre croissant
   */
  // On utilisera ici le tri par insertion.
  // Vous aurez besoin d'introduire des fonctions auxiliaires
  def triInsertion[B](l: List[B])(implicit ord: Ordering[B]): List[B] = {
    l match {
      case a :: as => insert(triInsertion(as)(ord), a, ord)
      case Nil     => Nil
    }
  }
  /**
   * @param l une liste d'entiers
   * @param ord ordre Nombre
   * @param ele element a trie
   * @return liste trier
   */
  def insert[B](l: List[B], ele: B, ord: Ordering[B]): List[B] = {
    l match {
      case a :: as => if (ord.gt(ele, a)) a :: insert(as, ele, ord) else a :: ele :: as
      case Nil     => List(ele)
    }
  }
  /**
   * @param l une liste d'entiers quelconque
   * @return vrai si et seulement si l est triée dans l'ordre croissant
   */
  def estTriee(l: List[Int]): Boolean = l.sorted == l

  /**
   * @param l1 une liste d'entiers
   * @param l2 une liste d'entiers
   * @return l2 est la version de l1 triée
   */
  def versionTriee(l1: List[Int], l2: List[Int]): Boolean = l1.sorted == l2

  print(triInsertion(List(1, 4, 7, 2, 5, 8, 3, 6, 9)))
}

//rep = rep.take(i).takeWhile(ord.lteq(_, ele)) ++ List(ele) ++ rep.take(i).dropWhile(ord.lteq(_, ele)) ++ l.drop(i + 1)
