package fr.istic.si2.test.tp5

import org.junit.Test
import org.junit.Assert._
import fr.istic.si2.scribble._
import fr.istic.si2.testerApp._
import fr.istic.si2.moreAssertions._
import fr.istic.si2.tp5._
import fr.istic.si2.tp5.ExosListes._

class TestsExosListes {

  val _ = new AppInit(ExosListes) // Ne pas supprimer

  // A vous de compléter les jeux de test !
  /**
   * Décrire le test
   */
  @Test(timeout=100)
  def test1() {
    assert(versionTriee(List(1,2,3,4,4,5,5,6,6,7,8,9),triInsertion(List(1,4,7,8,5,2,3,6,9,4,5,6))))
  }

}
