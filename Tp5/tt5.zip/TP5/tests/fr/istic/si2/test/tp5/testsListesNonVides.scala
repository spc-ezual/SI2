package fr.istic.si2.test.tp5

import org.junit.Test
import org.junit.Assert._
import fr.istic.si2.scribble._
import fr.istic.si2.testerApp._
import fr.istic.si2.moreAssertions._
import fr.istic.si2.tp5._
import fr.istic.si2.tp5.ExosListesNonVides._

class TestsExosListesNonVides {

  val _ = new AppInit(ExosListesNonVides) // Ne pas supprimer

  // A vous de compléter les jeux de test !
  /**
   * test dernier element list
   */
  @Test(timeout = 100)
  def dernierListTest() {
    val a = List(1, 5, 7, 9, 4, 3, 5, 7)
    assertEquals(a.last, dernier(a))
  }
  /**
   * test dernier element listNVE
   */
  @Test(timeout = 100)
  def dernierListNVETest() {
    val a = Constr(1, Constr(0, Nul))
    assertEquals(0, dernier(a))
  }

}
