package fr.istic.si2.tp3.restaurant

import fr.istic.si2.tp3.restaurant.Definitions._

object TestsInteractifs extends App {
  
  // Vous pouvez utiliser cette application 
  // pour tester vos fonctions au fur et à mesure à l'aide de println
  // pour afficher le resultat de vos fonctions sur des exemples
  
  val p : Plat = PoissonDuJour
  println(p)
  
}